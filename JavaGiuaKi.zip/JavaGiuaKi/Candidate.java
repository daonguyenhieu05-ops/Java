public abstract class Candidate {
    public static final int EXPERIENCE = 0;
    public static final int FRESHER = 1;
    public static final int INTERN = 2;

    private String candidateId;
    private String firstName;
    private String lastName;
    private int birthDate;      // năm sinh (1900..năm hiện tại)
    private String address;
    private String phone;
    private String email;
    private int candidateType;

    public Candidate(String candidateId, String firstName, String lastName, int birthDate,
                     String address, String phone, String email, int candidateType) {
        this.candidateId = candidateId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.candidateType = candidateType;
    }

    public String getCandidateId() { return candidateId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public int getBirthDate() { return birthDate; }
    public String getAddress() { return address; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public int getCandidateType() { return candidateType; }

    public String getFullName() { return firstName + " " + lastName; }

    // Định dạng dùng cho kết quả tìm kiếm
    @Override
    public String toString() {
        return getFullName() + " | " + birthDate + " | " + address + " | "
                + phone + " | " + email + " | " + candidateType;
    }
}
