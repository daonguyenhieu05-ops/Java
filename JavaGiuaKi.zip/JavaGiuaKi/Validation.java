import java.util.Calendar;
import java.util.Scanner;

public class Validation {
    private static final Scanner sc = new Scanner(System.in);
    public static final String[] RANKS = {"Excellence", "Good", "Fair", "Poor"};

    public static int currentYear() {
        return Calendar.getInstance().get(Calendar.YEAR);
    }

    // Nhap chuoi khong rong
    public static String inputString(String msg) {
        while (true) {
            System.out.print(msg);
            String s = sc.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Khong duoc de trong!");
        }
    }

    // Nhap so nguyen trong khoang [min, max]
    public static int inputInt(String msg, int min, int max) {
        while (true) {
            System.out.print(msg);
            String s = sc.nextLine().trim();
            try {
                int n = Integer.parseInt(s);
                if (n >= min && n <= max) return n;
            } catch (NumberFormatException e) {
                // roi xuong thong bao loi
            }
            System.out.println("Vui long nhap so nguyen tu " + min + " den " + max + "!");
        }
    }

    // BirthDate: so co dung 4 chu so, 1900..nam hien tai
    public static int inputBirthDate() {
        while (true) {
            String s = inputString("Nam sinh (year): ");
            if (s.matches("\\d{4}")) {
                int y = Integer.parseInt(s);
                if (y >= 1900 && y <= currentYear()) return y;
            }
            System.out.println("Nam sinh phai la so 4 chu so tu 1900 den " + currentYear() + "!");
        }
    }

    // Phone: toan chu so, toi thieu 10 ky tu
    public static String inputPhone() {
        while (true) {
            String s = inputString("SDT: ");
            if (s.matches("\\d{10,}")) return s;
            System.out.println("SDT phai la so va co it nhat 10 chu so!");
        }
    }

    // Email: <account name>@<domain>
    public static String inputEmail() {
        while (true) {
            String s = inputString("Email: ");
            if (s.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$")) return s;
            System.out.println("Email sai dinh dang <account name>@<domain>!");
        }
    }

    // Year of experience: 0..100
    public static int inputExpInYear() {
        return inputInt("Year of experience (0-100): ", 0, 100);
    }

    // Rank of graduation: Excellence, Good, Fair, Poor
    public static String inputRank() {
        while (true) {
            String s = inputString("Rank of graduation (gioi, kha, trung binh, kem): ");
            for (String r : RANKS) {
                if (r.equalsIgnoreCase(s)) return r;
            }
            System.out.println("Rank phai la mot trong: gioi, kha, trung binh, kem!");
        }
    }

    // Graduation date: nam tot nghiep 4 chu so
    public static String inputGraduationDate() {
        while (true) {
            String s = inputString("Graduation date (Nam tot nghiep): ");
            if (s.matches("\\d{4}")) {
                int y = Integer.parseInt(s);
                if (y >= 1900 && y <= currentYear() + 10) return s;
            }
            System.out.println("Graduation date khong hop le!");
        }
    }

    // Hoi tiep tuc Y/N
    public static boolean askContinue() {
        while (true) {
            System.out.print("Do you want to continue (Y/N)? ");
            String s = sc.nextLine().trim();
            if (s.equalsIgnoreCase("Y")) return true;
            if (s.equalsIgnoreCase("N")) return false;
            System.out.println("Chi nhap Y hoac N!");
        }
    }
}
