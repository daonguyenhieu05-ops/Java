public class Main {
    public static void main(String[] args) {
        CandidateManager manager = new CandidateManager();
        while (true) {
            System.out.println();
            System.out.println("CANDIDATE MANAGEMENT SYSTEM");
            System.out.println("1. Experience");
            System.out.println("2. Fresher");
            System.out.println("3. Internship");
            System.out.println("4. Searching");
            System.out.println("5. Exit");
            System.out.println("(Please choose 1 to Create Experience Candidate, 2 to Create Fresher Candidate,");
            System.out.println(" 3 to Internship Candidate, 4 to Searching and 5 to Exit program).");
            int choice = Validation.inputInt("Your choice: ", 1, 5);
            switch (choice) {
                case 1: manager.createExperience(); break;
                case 2: manager.createFresher(); break;
                case 3: manager.createIntern(); break;
                case 4: manager.search(); break;
                case 5:
                    System.out.println("Goodbye!");
                    return;
            }
        }
    }
}
