public class Fresher extends Candidate {
    private String graduationDate;
    private String graduationRank;
    private String education;

    public Fresher(String candidateId, String firstName, String lastName, int birthDate,
                   String address, String phone, String email,
                   String graduationDate, String graduationRank, String education) {
        super(candidateId, firstName, lastName, birthDate, address, phone, email, FRESHER);
        this.graduationDate = graduationDate;
        this.graduationRank = graduationRank;
        this.education = education;
    }

    public String getGraduationDate() { return graduationDate; }
    public String getGraduationRank() { return graduationRank; }
    public String getEducation() { return education; }
}
