public class Intern extends Candidate {
    private String majors;
    private int semester;
    private String universityName;

    public Intern(String candidateId, String firstName, String lastName, int birthDate,
                  String address, String phone, String email,
                  String majors, int semester, String universityName) {
        super(candidateId, firstName, lastName, birthDate, address, phone, email, INTERN);
        this.majors = majors;
        this.semester = semester;
        this.universityName = universityName;
    }

    public String getMajors() { return majors; }
    public int getSemester() { return semester; }
    public String getUniversityName() { return universityName; }
}
