import java.util.ArrayList;

public class CandidateManager {
    // Mỗi lọai ứng viên lưu trong một ArrayList riêng
    private ArrayList<Candidate> experiences = new ArrayList<>();
    private ArrayList<Candidate> freshers = new ArrayList<>();
    private ArrayList<Candidate> interns = new ArrayList<>();

    // Thông tin chung của mỗi ứng viên
    private String[] inputCommon() {
        String id = Validation.inputString("Candidate id: ");
        String first = Validation.inputString("First name: ");
        String last = Validation.inputString("Last name: ");
        String birth = String.valueOf(Validation.inputBirthDate());
        String address = Validation.inputString("Address: ");
        String phone = Validation.inputPhone();
        String email = Validation.inputEmail();
        return new String[]{id, first, last, birth, address, phone, email};
    }

    public void createExperience() {
        do {
            System.out.println("--- Create Experience Candidate ---");
            String[] c = inputCommon();
            int exp = Validation.inputExpInYear();
            String skill = Validation.inputString("Professional skill: ");
            experiences.add(new Experience(c[0], c[1], c[2], Integer.parseInt(c[3]),
                    c[4], c[5], c[6], exp, skill));
        } while (Validation.askContinue());
        displayAll();
    }

    public void createFresher() {
        do {
            System.out.println("--- Create Fresher Candidate ---");
            String[] c = inputCommon();
            String gradDate = Validation.inputGraduationDate();
            String rank = Validation.inputRank();
            String edu = Validation.inputString("University where graduated: ");
            freshers.add(new Fresher(c[0], c[1], c[2], Integer.parseInt(c[3]),
                    c[4], c[5], c[6], gradDate, rank, edu));
        } while (Validation.askContinue());
        displayAll();
    }

    public void createIntern() {
        do {
            System.out.println("--- Create Internship Candidate ---");
            String[] c = inputCommon();
            String majors = Validation.inputString("Majors: ");
            int semester = Validation.inputInt("Semester: ", 1, 20);
            String uni = Validation.inputString("University name: ");
            interns.add(new Intern(c[0], c[1], c[2], Integer.parseInt(c[3]),
                    c[4], c[5], c[6], majors, semester, uni));
        } while (Validation.askContinue());
        displayAll();
    }

    private void printGroup(String title, ArrayList<Candidate> list) {
        System.out.println("===========" + title + "============");
        for (Candidate c : list) {
            System.out.println(c.getFullName());
        }
    }

    public void displayAll() {
        System.out.println("List of candidate:");
        printGroup("EXPERIENCE CANDIDATE", experiences);
        printGroup("FRESHER CANDIDATE", freshers);
        printGroup("INTERN CANDIDATE", interns);
    }

    public void search() {
        displayAll();
        String name = Validation.inputString("Input Candidate name (First name or Last name): ");
        int type = Validation.inputInt("Input type of candidate: ", 0, 2);

        ArrayList<Candidate> source;
        if (type == Candidate.EXPERIENCE) source = experiences;
        else if (type == Candidate.FRESHER) source = freshers;
        else source = interns;

        String key = name.toLowerCase();
        boolean found = false;
        System.out.println("The candidates found:");
        for (Candidate c : source) {
            if (c.getFirstName().toLowerCase().contains(key)
                    || c.getLastName().toLowerCase().contains(key)) {
                System.out.println(c);
                found = true;
            }
        }
        if (!found) System.out.println("No candidate found!");
    }
}
