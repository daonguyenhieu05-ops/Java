/** Đại diện cho ứng viên đã có kinh nghiệm làm việc. */
public class Experience extends Candidate {
    /** Số năm kinh nghiệm làm việc. */
    private int expInYear;

    /** Kỹ năng chuyên môn của ứng viên. */
    private String proSkill;

    /**
     * Tạo ứng viên có kinh nghiệm cùng thông tin cá nhân và chuyên môn.
     */
    public Experience(String candidateId, String firstName, String lastName, int birthDate,
                      String address, String phone, String email, int expInYear, String proSkill) {
        super(candidateId, firstName, lastName, birthDate, address, phone, email, EXPERIENCE);
        this.expInYear = expInYear;
        this.proSkill = proSkill;
    }

    /** Trả về số năm kinh nghiệm làm việc. */
    public int getExpInYear() { return expInYear; }

    /** Trả về kỹ năng chuyên môn của ứng viên. */
    public String getProSkill() { return proSkill; }
}
